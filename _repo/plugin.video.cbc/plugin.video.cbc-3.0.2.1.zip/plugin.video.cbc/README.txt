plugin.video.cbc
================

Kodi Video Addon for CBC - for use in Canada only
For Kodi Isengard and later releases

V3.0.2 website change
V3.0.1 separate scraper for future functions
V2.0.9 unicode issue
V2.0.8 bump xbmc.python
V2.0.7 website changes
V2.0.6 unicode fix
V2.0.5 cleanup for release
V2.0.4 add latest 'the national' b'cast
V2.0.3 fix subtitles
V2.0.2 fix opener in getRequest
V2.0.1 initial v2 release

