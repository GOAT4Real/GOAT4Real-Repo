# -*- coding: utf-8 -*-

'''
    Copyright (C) 2017 fredko

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import json, random, re, sys, threading, time, urllib, urllib2, urlparse
import urlresolver, xbmc, xbmcgui
from resources.lib.modules import cache
from resources.lib.modules import client
from resources.lib.modules import control
from resources.lib.modules import log_utils
from resources.lib.modules import proxy

SCRAPE_SIZE_RE = re.compile(r'\b([,.][0-9]+|(?:0|[1-9][0-9]*)(?:[,.][0-9][0-9]?)?|[1-9](?:[.][0-9]{3})*(?:[,][0-9][0-9]?)?|[1-9](?:[,][0-9]{3})*(?:[.][0-9]+)?|[,.][0-9][0-9]?)(?:\s|_|&nbsp;)*([TGMK]i?[Bb]s?|(?:[Tt](?:era|ibi)|[Gg](?:iga|ibi)|[Mm](?:ega|ibi)|[Kk](?:ilo|ibi))?(?:[Bb]ytes|[Oo]ctets)|BYTES)\b')
TOPDOMAIN_RE = re.compile(r'(?i)https?://(?:www\.)?(?:[a-z0-9-]+\.)*?([a-z0-9-]+\.(?:[a-z]+|[a-z]{2,3}\.[a-z]{2,3}))(?:[:][0-9]+)?/')

SIZE_UNKNOWN = 0
SIZE_ERROR = -96
SIZE_DELETED = -451

def topdomain(url):
    groups = [['rapidgator.net','rg.to'],['uploaded.net','ul.to']]
    try: top = TOPDOMAIN_RE.match(url).group(1).lower()
    except: return None
    for grp in groups:
        if top in grp:
            top = grp[0]
            break
    return top

def formatted(size):
    if size >=  10L*1024*1024*1024:
        return   '%d GB' % (float(size) / (1024*1024*1024))
    elif size >= 1L*1024*1024*1024:
        return '%.1f GB' % (float(size) / (1024*1024*1024))
    elif size > 0:
        return '%.2f GB' % (float(size) / (1024*1024*1024))
    elif size == SIZE_UNKNOWN:
        return '[I]UNK[/I]'
    elif size == SIZE_ERROR:
        return '[I]ERR[/I]'
    elif size == SIZE_DELETED:
        return '[I]DEL[/I]'
    else:
        return '[I]ERR![/I]'

def cmp_size(a, b):
    try: aa = long(a.get('size', 0))
    except: aa = 0
    try: bb = long(b.get('size', 0))
    except: bb = 0
    return -1 if aa < bb else +1 if aa > bb else 0

def cmp_best(a, b):
    if a.get('local') != b.get('local'):
        return a.get('local', 0) - b.get('local', 0)
    try: aa = long(a.get('size', 0)) * _boost(a)
    except: aa = 0
    try: bb = long(b.get('size', 0)) * _boost(b)
    except: bb = 0
    return -1 if aa < bb else +1 if aa > bb else 0

def _boost(source):
    boost = 1.0
    name_or_url = source.get('name', '') or source['url'].split('|')[0].split('#')[0].split('/')[-1].replace('_', ' ').lower()

    # codec efficiency
    if re.search(r'(?i)\b(hevc|h\W?265|x265)\b(?!.*\bmp4\b)', name_or_url):
        boost = boost * 2.00
    elif re.search(r'(?i)\b(avc|h\W?264|x264|mp4)\b(?!.*\bavi\b)', name_or_url):
        pass
    elif re.search(r'(?i)\b(avi|divx|xvid)\b(?!.*\bmpe?g\b)', name_or_url):
        boost = boost * 0.50
    elif re.search(r'(?i)(\bmpeg|\.mpg)(?!\W*4.*)', name_or_url):
        boost = boost * 0.25

    # re-encoding penalty
    if re.search(r'(?i)\b(avc|h\W?264|x264|mp4)\b', name_or_url) and re.search(r'(?i)\b(hevc|h\W?265|x265|avi|divx|xvid)\b', name_or_url):
        boost = boost * 0.75

    # prefer certain hosters and classes of hoster
    if source.get('debrid') and re.search(r'[./](openload\.co|streamango\.com)/', source['url']): # cheapest on premiumize
        boost = boost * 1.25
    elif source.get('debrid') or source.get('debridonly') or source.get('memberonly'):
        boost = boost * 1.20
    elif source.get('source').lower() == 'gvideo' or source.get('direct'):
        boost = boost * 1.10

    # 'quality'
    if source['quality'] == 'CAM':
        boost = boost * 0.25

    return boost

def filter_sources(sources, resolve_list=None, scrape_list=None):
    try:
        log_utils.log('filesize/before = %s' % (json.dumps(sources)), log_utils.LOGDEBUG)
        try: resolve_list += []
        except: resolve_list = []
        try: scrape_list += []
        except: scrape_list = []
        scrape_list += ['rapidgator.net', 'turbobit.net', 'uploadgig.com']
        threads = _get_threads(sources, resolve_list, scrape_list, limit=100)
        _run_threads(sources, threads, 10)
        #TODO: update all sources to set 'size' instead
        for i in range(len(sources)):
            if 'info' in sources[i]:
                sources[i]['info'] = re.sub(r'\b\s*(\[B\]\[?)?(\d+|\d+\.\d+|\.\d+)\s*(MB|GB)(\]?\[/B\]\|)?\b', '', sources[i]['info']).strip()
        log_utils.log('filesize/after = %s' % (json.dumps(sources)), log_utils.LOGDEBUG)
    except Exception as e:
        exc_type, exc_obj, exc_tb = sys.exc_info()
        log_utils.log('Exception! line:%s %s %s' % (exc_tb.tb_lineno, type(e), e), log_utils.LOGERROR)

def _get_threads(sources, resolve_list, scrape_list, limit=None):
    try:
        def domains2match(domains):
            domains = '|'.join([re.escape(x) for x in domains])
            return '(?i)https?://(?:[a-z0-9-]+[.])*(' + domains + ')(?:[:][0-9]+)?/'

        openload_re = re.compile(domains2match(['openload.co', 'openload.io', 'oload.tv', 'oload.info', 'oload.stream']))
        streamango_re = re.compile(domains2match(['streamango.com', 'streamcherry.com']))
        nitroflare_re = re.compile(domains2match(['nitroflare.com']))
        filefactory_re = re.compile(domains2match(['filefactory.com']))
        uploaded_re = re.compile(domains2match(['uploaded.net', 'uploaded.to', 'ul.to']))
        lfichier_re = re.compile(domains2match(['1fichier.com', 'alterupload.com', 'cjoint.net', 'desfichiers.com', 'dfichiers.com', 'dl4free.com', 'megadl.fr', 'mesfichiers.org', 'piecejointe.net', 'pjointe.com', 'tenvoi.com']))
        keep2share_re = re.compile(domains2match(['keep2share.cc', 'keep2s.cc', 'k2s.cc']))
        rapidgator_re = re.compile(domains2match(['rapidgator.net', 'rg.to']))
        infoscrape_re = SCRAPE_SIZE_RE
        thevideo_re = re.compile(domains2match(['thevideo.me', 'tvad.me']))

        try: rg_resolver = [r for r in urlresolver.relevant_resolvers(domain='rapidgator.net', include_universal=False, include_disabled=True)
                            if r.name.lower() == 'rapidgator' and r.get_setting('enabled') == 'true' and r.get_setting('login') == 'true' and r.get_setting('password')][0]()
        except: rg_resolver = False

        library = []
        gvideo = []
        direct = []
        openload = []
        streamango = []
        nitroflare = []
        filefactory = []
        uploaded = []
        lfichier = []
        keep2share = []
        rapidgator = []
        thevideo = []
        otherdebrid = []
        resolver = []
        scraper = []

        hammered = {}
        maxhammer = 5
        rapidgator_notice = False

        for s in range(len(sources)):

            url = sources[s]['url']
            if sources[s].get('size'):
                pass
            elif sources[s].get('local'):
                log_utils.log('local source <%s>' % (sources[s]['info']), log_utils.LOGDEBUG)
                sources[s]['size'] = _xbmcvfs_size(sources[s]['url'])
            elif sources[s].get('direct'):
                log_utils.log('direct source <%s>' % (sources[s]['url']), log_utils.LOGDEBUG)
                direct.append(s)
            elif sources[s]['source'].lower() == 'gvideo':
                log_utils.log('gvideo source <%s>' % (sources[s]['url']), log_utils.LOGDEBUG)
                gvideo.append(s)
            elif openload_re.match(url):
                log_utils.log('openload source <%s>' % (sources[s]['url']), log_utils.LOGDEBUG)
                openload.append(s)
            elif streamango_re.match(url):
                log_utils.log('streamango source <%s>' % (sources[s]['url']), log_utils.LOGDEBUG)
                streamango.append(s)
            elif nitroflare_re.match(url):
                log_utils.log('nitroflare source <%s>' % (sources[s]['url']), log_utils.LOGDEBUG)
                nitroflare.append(s)
            elif filefactory_re.match(url):
                log_utils.log('filefactory source <%s>' % (sources[s]['url']), log_utils.LOGDEBUG)
                filefactory.append(s)
#            elif uploaded_re.match(url): # API reporting many files offline but still accessible via debrid...
#                log_utils.log('uploaded source <%s>' % (sources[s]['url']), log_utils.LOGDEBUG)
#                uploaded.append(s)
            elif lfichier_re.match(url):
                log_utils.log('1fichier source <%s>' % (sources[s]['url']), log_utils.LOGDEBUG)
                lfichier.append(s)
            elif keep2share_re.match(url):
                log_utils.log('keep2share source <%s>' % (sources[s]['url']), log_utils.LOGDEBUG)
                keep2share.append(s)
            elif rapidgator_re.match(url) and rg_resolver:
                log_utils.log('rapidgator source <%s>' % (sources[s]['url']), log_utils.LOGDEBUG)
                rapidgator.append(s)
            elif infoscrape_re.search(sources[s].get('info', '')):
                log_utils.log('scraping [info] <%s>' % (sources[s]['info']), log_utils.LOGDEBUG)
                sources[s]['size'] = scrape_size_from_text(sources[s]['info'])
            elif thevideo_re.match(url):
                log_utils.log('thevideo source <%s>' % (sources[s]['url']), log_utils.LOGDEBUG)
                if len(thevideo) >= maxhammer:
                    log_utils.log('not hammering thevideo', log_utils.LOGDEBUG)
                else:
                    thevideo.append(s)
            else:
                if not rapidgator_notice and rapidgator_re.match(url):
                    log_utils.log('free rapidgator account not found :(', log_utils.LOGNOTICE)
                    rapidgator_notice = True

                src = sources[s]['provider'] or 'UNKNOWN'
                top = topdomain(url)
                hammered.setdefault(src, 0)
                hammered.setdefault(top, 0)

                if src in resolve_list or top in resolve_list:
                    try: cached = cache.get_from_cache(_lookup, 1, url, 'resolver')
                    except: cached = None
                    if cached:
                        log_utils.log('cached resolver source <%s>' % (sources[s]['url']), log_utils.LOGDEBUG)
                        resolver.append(s)
                    elif hammered[src] >= maxhammer:
                        log_utils.log('not hammering %s' % (src), log_utils.LOGDEBUG)
                    elif hammered[top] >= maxhammer:
                        log_utils.log('not hammering %s' % (top), log_utils.LOGDEBUG)
                    else:
                        log_utils.log('resolver source %s' % (repr(url)), log_utils.LOGDEBUG)
                        hammered[src] = hammered.get(src, 0) + 1
                        hammered[top] = hammered.get(top, 0) + 1
                        resolver.append(s)

                elif src in scrape_list or top in scrape_list:
                    try: cached = cache.get_from_cache(_lookup, 1, url, 'scraper')
                    except: cached = None
                    if cached:
                        log_utils.log('cached scraper source <%s>' % (sources[s]['url']), log_utils.LOGDEBUG)
                        scraper.append(s)
                    elif hammered[src] >= maxhammer:
                        log_utils.log('not hammering %s' % (src), log_utils.LOGDEBUG)
                    elif hammered[top] >= maxhammer:
                        log_utils.log('not hammering %s' % (top), log_utils.LOGDEBUG)
                    else:
                        log_utils.log('scraper source %s' % (repr(url)), log_utils.LOGDEBUG)
                        hammered[src] = hammered.get(src, 0) + 1
                        hammered[top] = hammered.get(top, 0) + 1
                        scraper.append(s)

                elif sources[s].get('debridonly'):
                    try: cached = cache.get_from_cache(_lookup, 1, url, 'otherdebrid')
                    except: cached = None
                    if cached:
                        log_utils.log('cached otherdebrid source <%s>' % (sources[s]['url']), log_utils.LOGDEBUG)
                        otherdebrid.append(s)
                    elif hammered[src] >= maxhammer:
                        log_utils.log('not hammering %s' % (src), log_utils.LOGDEBUG)
                    elif hammered[top] >= maxhammer:
                        log_utils.log('not hammering %s' % (top), log_utils.LOGDEBUG)
                    else:
                        log_utils.log('otherdebrid source %s' % (repr(url)), log_utils.LOGDEBUG)
                        hammered[src] = hammered.get(src, 0) + 1
                        hammered[top] = hammered.get(top, 0) + 1
                        otherdebrid.append(s)

                else:
                    log_utils.log('unrecognised source <%s>' % (sources[s]['url']), log_utils.LOGDEBUG)
                    continue

                hammered[src] += 1
                hammered[top] += 1

        hipriority = []
        lopriority = []

        # direct
        while direct:
            i = direct.pop(0)
            lopriority.append(threading.Thread(target=_handle_singles, args=(sources[i], 'direct'), name='C'+str(i)))

        # gvideo
        while gvideo:
            i = gvideo.pop(0)
            lopriority.append(threading.Thread(target=_handle_singles, args=(sources[i], 'resolver'), name='G'+str(i)))

        # openload (batches of 50)
        while len(openload) > 0:
            hipriority.append(threading.Thread(target=_handle_batches, args=(sources, openload[:50], 'openload'), name='O'))
            openload = openload[50:]

        # streamango (batches of 50)
        while len(streamango) > 0:
            hipriority.append(threading.Thread(target=_handle_batches, args=(sources, streamango[:50], 'streamango'), name='M'))
            streamango = streamango[50:]

        # nitroflare (batches of 100)
        while len(nitroflare) > 0:
            hipriority.append(threading.Thread(target=_handle_batches, args=(sources, nitroflare[:100], 'nitroflare'), name='N'))
            nitroflare = nitroflare[100:]

        # filefactory (batches of 100)
        while len(filefactory) > 0:
            hipriority.append(threading.Thread(target=_handle_batches, args=(sources, filefactory[:100], 'filefactory'), name='F'))
            filefactory = filefactory[100:]

        # uploaded (in batches -- unknown limit, try 50)
        while len(uploaded) > 0:
            hipriority.append(threading.Thread(target=_handle_batches, args=(sources, uploaded[:50], 'uploaded'), name='U'))
            uploaded = uploaded[50:]

        # 1fichier (in batches -- unknown limit, try 50)
        while len(lfichier) > 0:
            hipriority.append(threading.Thread(target=_handle_batches, args=(sources, lfichier[:50], '1fichier'), name='I'))
            lfichier = lfichier[50:]

        # keep2share (in batches -- unknown limit, try 50)
        while len(keep2share) > 0:
            hipriority.append(threading.Thread(target=_handle_batches, args=(sources, keep2share[:50], 'keep2share'), name='K'))
            keep2share = keep2share[50:]

        # rapidgator (batches of 25)
        while rapidgator:
            hipriority.append(threading.Thread(target=_handle_batches, args=(sources, rapidgator[:25], 'rapidgator'), kwargs={'resolver':rg_resolver}, name='R'))
            rapidgator = rapidgator[25:]

        random.shuffle(hipriority)
        random.shuffle(lopriority)

        # thevideo
        while thevideo:
            i = thevideo.pop(0)
            lopriority.append(threading.Thread(target=_handle_singles, args=(sources[i], 'thevideo'), name='V'+str(i)))

        # other premium hosts that we don't handle seperately yet
        while otherdebrid:
            i = otherdebrid.pop(0)
            lopriority.append(threading.Thread(target=_handle_singles, args=(sources[i], 'otherdebrid'), name='P'+str(i)))

        # other hosts
        while resolver:
            i = resolver.pop(0)
            lopriority.append(threading.Thread(target=_handle_singles, args=(sources[i], 'resolver'), name='@'+str(i)))

        # other hosts
        while scraper:
            i = scraper.pop(0)
            lopriority.append(threading.Thread(target=_handle_singles, args=(sources[i], 'scraper'), name='#'+str(i)))

        if limit is None:
            return hipriority + lopriority
        elif len(hipriority) < limit:
            return hipriority + lopriority[0:limit-len(hipriority)-1]
        else:
            return hipriority

    except Exception as e:
        exc_type, exc_value, exc_tb = sys.exc_info()
        log_utils.log('Exception! line:%s %s %s' % (exc_tb.tb_lineno, type(e), e), log_utils.LOGERROR)

def _run_threads(sources, threads, maxrunning):
    try:
        try: timeout = int(control.setting('scrapers.timeout.1'))
        except: timeout = 10
        timeout = min(max(timeout, 10), 60)

        def line_about_thread(sources, t):
            mapped = {'O':'Openload', 'M':'Streamango', 'N':'Nitroflare', 'F':'Filefactory', 'U':'Uploaded', 'I':'1fichier', 'K':'keep2share', 'R':'Rapidgator'}
            name = t.getName()
            try:
                if len(name) == 1:
                    return mapped[name]
                s = int(name[1:])
                return sources[s]['url']
            except:
                return name

        try:
            if control.progressDialogBG: control.progressDialogBG.close()
        except: pass
        progressDialog = control.progressDialog if control.setting('progress.dialog') == '0' else control.progressDialogBG
        progressDialog.create(control.addonInfo('name'), 'Starting...')
        progressDialog.update(0)
        wascanceled = progressDialog.iscanceled()

        threads.reverse() # put the more important stuff at the end, so we can pop()
        started = []

        t0 = time.time()
        for i in range(0, timeout * 2):
            try:
                if xbmc.abortRequested == True: return sys.exit()
                if progressDialog.iscanceled() and (not wascanceled or i >= 10 * 2): break
            except:
                pass

            numalive = len([x for x in started if x.isAlive() == True])
            numadded = 0
            while numalive + numadded < maxrunning and threads:
                started.append(threads.pop())
                started[-1].start()
                numadded += 1

            try:
                alive = [x for x in started if x.isAlive()]
                if len(alive) == 0 and len(threads) == 0: break
                line1 = line_about_thread(sources, alive[0]) if alive else ' '
                line2 = ' '.join([x.getName()[0] for x in alive]) + ' +' * numadded
                line3 = ''
                line3 = '%.1f seconds' % (time.time()-t0)
                percent1 = 100 * float(i) / (2 * timeout)
                percent2 = 100 - 100 * (len(alive) + len(threads)) / (len(started) + len(threads))
                progressDialog.update(max(1, int(percent1 + 0.5), int(percent2 + 0.5)), line1, line2, line3)
            except Exception as e:
                exc_type, exc_value, exc_tb = sys.exc_info()
                log_utils.log('Exception! line:%s %s %s' % (exc_tb.tb_lineno, type(e), e), log_utils.LOGERROR)

            time.sleep(0.5)

        try: progressDialog.close()
        except: pass

    except Exception as e:
        exc_type, exc_value, exc_tb = sys.exc_info()
        log_utils.log('Exception! line:%s %s %s' % (exc_tb.tb_lineno, type(e), e), log_utils.LOGERROR)

def _handle_batches(sources, slist, hoster, resolver=None):
    try:
        docids = []
        for s in slist:
            if hoster == '1fichier':
                docid = sources[s]['url']
            elif hoster == 'rapidgator':
                docid = sources[s]['url'].replace('"', "'")
            else:
                pathpattern = '(?:/embed|/f|/file|/stream|/view)?/([0-9A-Za-z_-]{8,})(?=[/?]|$)'
                match = re.match('https?://[^/]+' + pathpattern, sources[s]['url'])
                docid = match.group(1) if match else None
            docids.append(docid)

        sorted_docids = sorted(list(set(docids))) # cache better

        name_key = 'name'
        size_key = 'size'

        if False:
            pass
        elif hoster == 'openload':
            api_url = 'https://api.openload.co/1/file/info?file=' + ','.join(sorted_docids)
            text = cache.get(_api_call, 1, api_url, None)
            response = json.loads(text)['result']
        elif hoster == 'streamango':
            api_url = 'https://api.fruithosted.net/file/info?file=' + ','.join(sorted_docids)
            text = cache.get(_api_call, 1, api_url, None)
            response = json.loads(text)['result']
        elif hoster == 'nitroflare':
            api_url = 'https://www.nitroflare.com/api/v2/getFileInfo?files=' + ','.join(sorted_docids)
            text = cache.get(_api_call, 1, api_url, None)
            response = json.loads(text)['result']['files']
        elif hoster == 'filefactory':
            api_url = 'https://api.filefactory.com/v1/getFileInfo?file=' + ','.join(sorted_docids)
            text = cache.get(_api_call, 1, api_url, None)
            response = json.loads(text)['result']['files']
        elif hoster == 'uploaded':
            argx = []
            for docid in sorted_docids:
                argx.append('id_%d=%s' % (len(argx), '' if docid is None else docid))
            apikey = 'lhF2IeeprweDfu9ccWlxXVVypA5nA3EL'
            api_url = 'https://www.uploaded.net/api/filemultiple?apikey=' + apikey + '&' + '&'.join(argx)
            text = cache.get(_api_call, 1, api_url, None)
            response = {}
            for line in text.split('\n'):
                fields = line.split(',', 4)
                if len(fields) != 5:
                    continue
                response[fields[1]] = {'size': fields[2], 'name': fields[4]}
            log_utils.log('@@@@ UPLOADED %s %s %s' % (repr(api_url), repr(text), json.dumps(response)), log_utils.LOGNOTICE)
        elif hoster == '1fichier':
            argx = []
            for docid in sorted_docids:
                argx.append('links[]=%s' % (docid))
            api_url = 'https://1fichier.com/check_links.pl'
            text = cache.get(_api_call, 1, api_url, '&'.join(argx))
            response = {}
            for line in text.split('\n'):
                fields = line.split(';')
                if len(fields) < 3:
                    continue
                response[fields[0]] = {'size': fields[2], 'name': fields[1]}
        elif hoster == 'keep2share':
            api_url = 'http://keep2share.cc/api/v2/GetFilesInfo'
            text = cache.get(_api_call, 1, api_url, json.dumps({'ids':sorted_docids}))
            data = json.loads(text)
            response = {}
            for file in data['files']:
                if file.get('is_available') == False:
                    file['size'] = False
                response[file['id']] = file
        elif hoster == 'rapidgator':
            api_url = '["' + '","'.join(sorted_docids) + '"]'
            text = cache.get(resolver.api_call, 1, '/file/check_link', {'url': api_url})
            response = dict((doc['url'].replace(r'\/', '/'), doc) for doc in text)
            name_key = 'filename'
        else:
            log_utils.log('_handle_batches() unknown hoster "%s"' % (hoster), log_utils.LOGERROR)
            return

        for i in range(len(slist)):
            s = slist[i]
            docid = docids[i]

            if docid is None:
                log_utils.log('docid parse Exception! %s' % (repr(sources[s]['url'])), log_utils.LOGERROR)
                continue
            if docid not in response:
                log_utils.log('docid not found %s' % (repr(sources[s]['url'])), log_utils.LOGWARNING)
                continue

            try: size = long(response[docid][size_key])
            except: size = 0
            if size < 1:
                size = SIZE_DELETED
            try: name = response[docid][name_key]
            except: name = None

            sources[s]['size'] = size
            if name and not sources[s].get('name'):
                sources[s]['name'] = name

    except Exception as e:
        exc_type, exc_value, exc_tb = sys.exc_info()
        log_utils.log('Exception! line:%s %s %s' % (exc_tb.tb_lineno, type(e), e), log_utils.LOGERROR)

def _api_call(url, data):
    XHR = bool('thevideo.me/download/getqualities/' in url)
    return client.request(url, post=data, XHR=XHR, timeout=10)

def _handle_singles(source, how):
    try:
        (size, name) = cache.get(_lookup, 8, source['url'], how)

        source['size'] = size
        if name and not source.get('name'):
            source['name'] = name

    except Exception as e:
        exc_type, exc_value, exc_tb = sys.exc_info()
        log_utils.log('Exception! line:%s %s %s' % (exc_tb.tb_lineno, type(e), e), log_utils.LOGERROR)

def _lookup(url, how):
    if how == 'thevideo':
        return _lookup_thevideo(url)
    if how == 'otherdebrid':
        return _lookup_otherdebrid(url)

    status = None

    if how == 'resolver':
        t0 = time.time()

        try:
            hmf = urlresolver.HostedMediaFile(url=url, include_universal=False)
        except Exception as e:
            log_utils.log('Exception! HostedMediaFile(%s) %s %s' % (repr(url), type(e), e), log_utils.LOGERROR)
            return (SIZE_ERROR, None)

        try:
            resolved = hmf.resolve(allow_popups=False)
        except urllib2.HTTPError as e:
            try: status = int(e.code)
            except: status = 0
        except Exception as e:
            log_utils.log('Exception! hmf.resolve(%s) %s %s' % (repr(url), type(e), e), log_utils.LOGDEBUG)
            if re.match(r'(?i)https?://([a-z0-9-]+\.)*(flashx|streamin|vidup|vshare|openload|thevideo)\.([a-z]{2})[:/]', url):
                return (SIZE_UNKNOWN, None)
            else:
                return (SIZE_DELETED, None)
        else:
            t1 = time.time()
            if resolved is False:
                log_utils.log('resolved<%s> = %s in %.2f seconds' % (url, repr(resolved), time.time()-t0), log_utils.LOGERROR)
                return (SIZE_ERROR, None)
            elif (t1-t0) >= 1:
                log_utils.log('resolved<%s> = %s in %.2f seconds' % (url, repr(resolved), time.time()-t0), log_utils.LOGWARNING)
            else:
                log_utils.log('resolved<%s> = %s' % (url, repr(resolved)), log_utils.LOGNOTICE)
            url = resolved

    if how == 'resolver' or how == 'direct':
        try:
            headers = dict([item.split('=') for item in (url.split('|')[1]).split('&')])
            for header in headers:
                headers[header] = urllib.unquote_plus(headers[header])
            url = url.split('|')[0]
        except:
            headers = {}
        stream = True
    else:
        headers = {}
        stream = False

    if status is None or (status >= 200 and status < 300):
        try:
            text, status, headers, _headers, _cookies = client.request(url, output='extended', headers=headers, error=True, limit=10, timeout=10)
            status = int(status)
        except Exception as e:
            log_utils.log('Exception! client.request(%s) %s %s' % (repr(url), type(e), e), log_utils.LOGERROR)
            return (SIZE_ERROR, None)
    else:
        status = 0

    if not status:
        log_utils.log('HTTP ??? <%s>' % (url), log_utils.LOGWARNING)
        return (SIZE_UNKNOWN, None)
    elif status >= 300 and status < 400:
        log_utils.log('HTTP %d <%s>' % (status, url), log_utils.LOGWARNING)
        return (SIZE_ERROR, None)
    elif status >= 400 and status < 500:
        if status in [404, 429, 451]:
            log_utils.log('HTTP %d <%s>' % (status, url), log_utils.LOGDEBUG)
        else:
            log_utils.log('HTTP %d <%s>' % (status, url), log_utils.LOGWARNING)
        return (SIZE_DELETED, None)
    elif status >= 500 and status < 600:
        log_utils.log('HTTP %d <%s>' % (status, url), log_utils.LOGWARNING)
        return (SIZE_UNKNOWN, None)
    else:
        log_utils.log('HTTP %d <%s>' % (status, url), log_utils.LOGDEBUG)

    if re.search(r'\.m3u8?\b', url):
        log_utils.log('PLAYLIST <%s>' % (url), log_utils.LOGDEBUG)
        return (SIZE_UNKNOWN, None)

    if not headers:
        log_utils.log('TIMEOUT <%s>' % (url), log_utils.LOGWARNING)
        return (SIZE_UNKNOWN, None)
    elif how == 'resolver' or how == 'direct':
        try:
            size = long(headers.get('Content-Length'))
        except:
            size = None
        log_utils.log('LENGTH %s %s <%s>' % (repr(size), repr(headers), url), log_utils.LOGDEBUG)
        if size < 1024*1024:
            return (SIZE_DELETED, None)
        return (size, None)

    if re.search(r'\b((file|was) not found|no such file|(been|got|was) (deleted|removed))\b', text, flags=re.I):
        log_utils.log('DELETED <%s>' % (url), log_utils.LOGDEBUG)
        return (SIZE_DELETED, None)
    else:
        top = topdomain(url)
        size = scrape_size_from_text(text, missing=SIZE_UNKNOWN)
        name = scrape_name_from_html(text, hoster=top)
        log_utils.log('SCRAPED %s %s <%s>' % (repr(size), repr(name), url), log_utils.LOGDEBUG)
        return (size, name)

def scrape_size_from_text(text, missing=None):
    size = None

    for num, units in re.findall(SCRAPE_SIZE_RE, text):
        if ',' in num[-3:] or num.startswith(','):
            num = num.replace('.', '').replace(',', '.')
        else:
            num = num.replace(',', '')
        try: num = float(num) if '.' in num else long(num)
        except: continue
        units = units.lower()

        if units.startswith('g'):
            n = long(num * 1024*1024*1024 + 0.5)
        elif units.startswith('m'):
            n = long(num * 1024*1024 + 0.5)
        elif units.startswith('k'):
            n = long(num * 1024 + 0.5)
        else:
            n = long(num + 0.5)

        if size is None:
            size = n
        else:
            size = min(size, n)

    if size is None:
        return missing
    if (size < 10L*1024*1024) or (size >= 100L*1024*1024*1024):
        return missing
    return size

def scrape_name_from_html(html, hoster=None):
    try:
        title = re.search(r'<title(?:\s[^<>]*>)?>\s*(.*?)\s*</title(?=>|\s)', html, flags=re.I|re.DOTALL).group(1)
        title = re.sub(r'\s+', ' ', title)
    except:
        return None

    try:
        hoster = hoster.split('.')[0].lower()
        hoster = re.escape(hoster)
    except:
        hoster = '(?!)' # never matches

    pattern = r'(^\W*'+hoster+'\W.*|^\W*(download\s*|watch\s*|file\s*)*\W+|([^\w)]+online)?([^\w)]+'+hoster+r'([.][a-z]+)?)?\W*$|^no title$)'
    name = re.sub(pattern, '', title, flags=re.I)
    return name

def _lookup_thevideo(url):
    try:
        pattern = r'(?://|\.)((?:thevideo|tvad)\.me)/(?:embed-|download/)?([0-9a-zA-Z]+)' # copied from urlresolver
        docid = re.search(pattern, url, re.I).group(2)
    except:
        log_utils.log('[thevideo] docid not found in %s' % (repr(url)), log_utils.LOGERROR)
        return (SIZE_ERROR, None)

    try:
        api_url = 'https://thevideo.me/download/getqualities/%s?json' % (docid)
        text = _api_call(api_url, None)
    except Exception as e:
        log_utils.log('Exception! _api_call(%s) %s %s' % (repr(api_url), type(e), e), log_utils.LOGERROR)
        return (SIZE_UNKNOWN, None)

    try:
        data = json.loads(text)
        response = data['response']
    except Exception as e:
        exc_type, exc_value, exc_tb = sys.exc_info()
        log_utils.log('Exception! line:%s %s %s' % (exc_tb.tb_lineno, type(e), e), log_utils.LOGERROR)
        return (SIZE_ERROR, None)

    try:
        if isinstance(response, basestring):
            log_utils.log('[thevideo:%s] bad response' % (docid), log_utils.LOGERROR)
            return (SIZE_ERROR, None)

        maxsize = None
        for vid in response:
            if vid.get('file_code', docid) != docid:
                log_utils.log('[thevideo:%s] unexpected docid' % (docid), log_utils.LOGERROR)
                continue

            try:
                vidsize = long(vid['file_size'])
            except:
                vidsize = None

            if vidsize <= 1: # thevideo can report the file_size as '1'
                log_utils.log('[thevideo:%s] bad file_size' % (docid), log_utils.LOGERROR)
                try:
                    vidsize = scrape_size_from_text(vid['file_size_mb'], conflict=None)
                except:
                    vidsize = None

            if vidsize <= 1: # thevideo can report the file_size_mb as '1 B'
                log_utils.log('[thevideo:%s] bad file_size_mb' % (docid), log_utils.LOGERROR)
                try:
                    vid_bitrate = long(vid['vid_bitrate'])
                    vid_audio_bitrate = long(vid['vid_audio_bitrate'])
                    vid_length = long(vid['vid_length'])
                    vidsize = (vid_bitrate + vid_audio_bitrate) * vid_length * 125 # approx
                except:
                    vidsize = None

            if vidsize <= 1:
                log_utils.log('[thevideo:%s] bad bitrates' % (docid), log_utils.LOGERROR)
            elif vidsize > maxsize:
                maxsize = vidsize

    except Exception as e:
        exc_type, exc_value, exc_tb = sys.exc_info()
        log_utils.log('Exception! line:%s %s %s' % (exc_tb.tb_lineno, type(e), e), log_utils.LOGERROR)
        return (SIZE_ERROR, None)

    if maxsize is None:
        log_utils.log('[thevideo:%s] no responses' % (docid), log_utils.LOGERROR)
        return (SIZE_DELETED, None)

    return (maxsize, None)

def _lookup_otherdebrid(url):
    try:
        api_url = 'https://api.real-debrid.com/rest/1.0/unrestrict/check'
        proxied = random.shuffle(proxy.get())[0] + urllib.quote_plus(api_url)
        text = _api_call(proxied, {'link': url})
    except:
        return (SIZE_UNKNOWN, None)

    try:
        response = json.loads(text)
    except:
        log_utils.log('[otherdebrid] json error', log_utils.LOGERROR)
        return (SIZE_UNKNOWN, None)

    try:
        return (long(response['filesize']), response.get('filename'))
    except:
        return (SIZE_DELETED, None)

def _xbmcvfs_size(url):
    try:
        f = control.openFile(url)
        if not f:
            return SIZE_DELETED
    except:
        return SIZE_DELETED

    try:
        size = long(f.size())
        if not f:
            size = SIZE_ERROR
    except:
        size = SIZE_ERROR

    try:
        f.close()
    except:
        pass

    return size